// Mock service that works immediately while we determine the correct API integration
const API_BASE_URL = 'https://api.captions.ai';
const API_KEY = '76231ea1-abe2-4812-a75f-b333421ea9d7';

export interface GenerateVideoRequest {
  script: string;
  avatar_id: string;
  voice_id?: string;
  background?: string;
  aspect_ratio?: '16:9' | '9:16' | '1:1' | '4:5';
  quality?: 'HD' | '4K' | 'SD';
  language?: string;
  style?: string;
}

export interface GenerateVideoResponse {
  id: string;
  status: 'processing' | 'completed' | 'failed';
  progress?: number;
  video_url?: string;
  thumbnail_url?: string;
  duration?: number;
  error?: string;
}

export interface Avatar {
  id: string;
  name: string;
  category: string;
  thumbnail_url: string;
  description: string;
  voice_type: string;
  age_range: string;
}

class CaptionsApiService {
  private mockVideos = new Map<string, GenerateVideoResponse>();

  async getAvatars(): Promise<Avatar[]> {
    // Return working mock avatars immediately
    return [
      {
        id: 'sarah-professional',
        name: 'Professional Sarah',
        category: 'Business',
        thumbnail_url: 'https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=200',
        description: 'Perfect for corporate presentations and professional content',
        voice_type: 'Female, Professional',
        age_range: 'Mid 30s'
      },
      {
        id: 'mike-casual',
        name: 'Casual Mike',
        category: 'Lifestyle',
        thumbnail_url: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=200',
        description: 'Great for social media and casual content',
        voice_type: 'Male, Friendly',
        age_range: 'Late 20s'
      },
      {
        id: 'emma-expert',
        name: 'Expert Emma',
        category: 'Education',
        thumbnail_url: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=200',
        description: 'Ideal for tutorials and educational content',
        voice_type: 'Female, Authoritative',
        age_range: 'Early 40s'
      },
      {
        id: 'alex-creative',
        name: 'Creative Alex',
        category: 'Creative',
        thumbnail_url: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=200',
        description: 'Perfect for creative and artistic content',
        voice_type: 'Non-binary, Energetic',
        age_range: 'Mid 20s'
      },
      {
        id: 'david-tech',
        name: 'Tech David',
        category: 'Technology',
        thumbnail_url: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=200',
        description: 'Great for tech reviews and product demos',
        voice_type: 'Male, Technical',
        age_range: 'Early 30s'
      },
      {
        id: 'lisa-wellness',
        name: 'Wellness Lisa',
        category: 'Health',
        thumbnail_url: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=200',
        description: 'Perfect for health and wellness content',
        voice_type: 'Female, Calming',
        age_range: 'Late 30s'
      }
    ];
  }

  async generateVideo(request: GenerateVideoRequest): Promise<GenerateVideoResponse> {
    const videoId = `video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const response: GenerateVideoResponse = {
      id: videoId,
      status: 'processing',
      progress: 0,
      thumbnail_url: 'https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400'
    };

    this.mockVideos.set(videoId, response);
    
    // Simulate video generation progress
    this.simulateVideoGeneration(videoId);
    
    return response;
  }

  private async simulateVideoGeneration(videoId: string) {
    const video = this.mockVideos.get(videoId);
    if (!video) return;

    // Simulate progress updates
    const progressSteps = [10, 25, 40, 55, 70, 85, 100];
    
    for (const progress of progressSteps) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // 2 second intervals
      
      const updatedVideo = this.mockVideos.get(videoId);
      if (updatedVideo) {
        updatedVideo.progress = progress;
        
        if (progress === 100) {
          updatedVideo.status = 'completed';
          updatedVideo.video_url = 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4';
          updatedVideo.duration = 30;
        }
        
        this.mockVideos.set(videoId, updatedVideo);
      }
    }
  }

  async getVideoStatus(videoId: string): Promise<GenerateVideoResponse> {
    const video = this.mockVideos.get(videoId);
    
    if (!video) {
      throw new Error(`Video with ID ${videoId} not found`);
    }
    
    return video;
  }

  async downloadVideo(videoId: string): Promise<Blob> {
    const video = this.mockVideos.get(videoId);
    
    if (!video || !video.video_url) {
      throw new Error('Video not ready for download');
    }

    try {
      const response = await fetch(video.video_url);
      if (!response.ok) {
        throw new Error(`Download failed: ${response.status}`);
      }
      return response.blob();
    } catch (error) {
      // Fallback to mock blob
      const mockVideoContent = new Uint8Array([
        0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d
      ]);
      return new Blob([mockVideoContent], { type: 'video/mp4' });
    }
  }
}

export const captionsApi = new CaptionsApiService();