const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN || 'r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75';

export default async function handler(req, res) {
  // Handle CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const videoId = req.query.id;

    if (!videoId) {
      return res.status(400).json({ error: 'Video ID is required' });
    }

    if (!REPLICATE_API_TOKEN) {
      return res.status(500).json({ 
        error: 'REPLICATE_API_TOKEN not configured',
        details: 'Please set the environment variable in Vercel dashboard'
      });
    }

    console.log('🔍 Checking video status:', videoId);

    const response = await fetch(`https://api.replicate.com/v1/predictions/${videoId}`, {
      headers: {
        'Authorization': `Token ${REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
    });

    console.log('📊 Status response:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Replicate API error:', response.status, errorText);
      
      // Handle specific error cases
      if (response.status === 404) {
        return res.status(404).json({
          error: 'Video not found',
          details: 'The video ID may be incorrect or the video may have been deleted'
        });
      } else if (response.status === 401) {
        return res.status(401).json({
          error: 'Authentication failed',
          details: 'Please check your Replicate API token configuration'
        });
      } else {
        return res.status(response.status).json({
          error: `API request failed: ${response.status}`,
          details: errorText
        });
      }
    }

    const prediction = await response.json();
    console.log('📊 Video status update:', prediction.status, prediction.id);

    // Handle different output formats
    let videoUrl;
    if (prediction.output) {
      if (Array.isArray(prediction.output)) {
        videoUrl = prediction.output.find(url => 
          typeof url === 'string' && (url.includes('.mp4') || url.includes('.mov') || url.includes('video'))
        ) || prediction.output[0];
      } else if (typeof prediction.output === 'string') {
        videoUrl = prediction.output;
      } else if (prediction.output.video) {
        videoUrl = prediction.output.video;
      }
    }

    const result = {
      id: prediction.id,
      status: mapStatus(prediction.status),
      progress: calculateProgress(prediction.status, prediction.logs),
      video_url: videoUrl,
      duration: videoUrl ? estimateDuration(prediction.logs || '') : undefined,
      error: prediction.error || undefined,
      logs: prediction.logs || 'Processing...',
      model: prediction.version ? getModelName(prediction.version) : 'AI Video Model'
    };

    if (result.status === 'completed' && videoUrl) {
      console.log('🎉 Video generation completed!', videoUrl);
    } else if (result.status === 'failed') {
      console.log('❌ Video generation failed:', prediction.error);
    }

    return res.status(200).json(result);

  } catch (error) {
    console.error('💥 Video status error:', error);
    
    return res.status(500).json({
      error: error.message || 'Unknown error occurred',
      details: 'Failed to get video status',
      token_status: REPLICATE_API_TOKEN ? 'Token present' : 'Token missing'
    });
  }
}

function mapStatus(status) {
  switch (status) {
    case 'succeeded': return 'completed';
    case 'failed':
    case 'canceled': return 'failed';
    default: return 'processing';
  }
}

function calculateProgress(status, logs) {
  if (logs) {
    const progressMatch = logs.match(/(\d+)%/);
    if (progressMatch) {
      return parseInt(progressMatch[1]);
    }
    
    const stepMatch = logs.match(/step (\d+)\/(\d+)/i);
    if (stepMatch) {
      const current = parseInt(stepMatch[1]);
      const total = parseInt(stepMatch[2]);
      return Math.round((current / total) * 100);
    }
  }

  switch (status) {
    case 'starting': return 15;
    case 'processing': return 60;
    case 'succeeded': return 100;
    case 'failed':
    case 'canceled': return 0;
    default: return 10;
  }
}

function estimateDuration(logs) {
  const durationMatch = logs.match(/duration[:\s]+(\d+)/i);
  return durationMatch ? parseInt(durationMatch[1]) : 5;
}

function getModelName(version) {
  if (version.includes('stable-video-diffusion')) return 'Stable Video Diffusion';
  if (version.includes('zeroscope')) return 'ZeroScope V2 XL';
  if (version.includes('damo')) return 'Damo Text-to-Video';
  return 'AI Video Model';
}