import { useState, useCallback } from 'react';
import { videoGenerationApi, GenerateVideoRequest, GenerateVideoResponse } from '../services/videoGenerationApi';

export interface VideoGenerationState {
  isGenerating: boolean;
  progress: number;
  videoId: string | null;
  videoUrl: string | null;
  error: string | null;
  status: 'idle' | 'processing' | 'completed' | 'failed';
  logs: string | null;
}

export const useVideoGeneration = () => {
  const [state, setState] = useState<VideoGenerationState>({
    isGenerating: false,
    progress: 0,
    videoId: null,
    videoUrl: null,
    error: null,
    status: 'idle',
    logs: null
  });

  const generateVideo = useCallback(async (request: GenerateVideoRequest) => {
    console.log('🎬 Starting video generation process...');
    
    setState(prev => ({
      ...prev,
      isGenerating: true,
      progress: 0,
      error: null,
      status: 'processing',
      logs: 'Initializing video generation...',
      videoUrl: null,
      videoId: null
    }));

    try {
      // Start video generation - this ALWAYS works
      const response = await videoGenerationApi.generateVideo(request);
      
      setState(prev => ({
        ...prev,
        videoId: response.id,
        progress: response.progress || 0,
        status: response.status,
        logs: response.logs || 'Video generation started...'
      }));

      // Poll for status updates every 1 second for smooth progress
      const pollInterval = setInterval(async () => {
        try {
          if (!response.id) return;
          
          const statusResponse = await videoGenerationApi.getVideoStatus(response.id);
          
          setState(prev => ({
            ...prev,
            progress: statusResponse.progress || prev.progress,
            status: statusResponse.status,
            videoUrl: statusResponse.video_url || prev.videoUrl,
            logs: statusResponse.logs || prev.logs
          }));

          if (statusResponse.status === 'completed') {
            setState(prev => ({
              ...prev,
              isGenerating: false,
              progress: 100,
              videoUrl: statusResponse.video_url || prev.videoUrl,
              status: 'completed'
            }));
            clearInterval(pollInterval);
            console.log('🎉 Video generation completed successfully!');
          } else if (statusResponse.status === 'failed') {
            setState(prev => ({
              ...prev,
              isGenerating: false,
              error: statusResponse.error || 'Video generation failed',
              status: 'failed'
            }));
            clearInterval(pollInterval);
            console.error('❌ Video generation failed');
          }
        } catch (error) {
          console.error('Error polling video status:', error);
          // Don't fail on polling errors, just continue
        }
      }, 1000); // Poll every 1 second for smooth updates

      // Cleanup interval after 2 minutes (more than enough time)
      setTimeout(() => {
        clearInterval(pollInterval);
        setState(prev => {
          if (prev.isGenerating) {
            return {
              ...prev,
              isGenerating: false,
              error: 'Video generation timed out',
              status: 'failed'
            };
          }
          return prev;
        });
      }, 120000); // 2 minutes timeout

    } catch (error) {
      console.error('Failed to start video generation:', error);
      setState(prev => ({
        ...prev,
        isGenerating: false,
        error: error instanceof Error ? error.message : 'Failed to start video generation',
        status: 'failed'
      }));
    }
  }, []);

  const resetGeneration = useCallback(() => {
    setState({
      isGenerating: false,
      progress: 0,
      videoId: null,
      videoUrl: null,
      error: null,
      status: 'idle',
      logs: null
    });
  }, []);

  const cancelGeneration = useCallback(async () => {
    if (!state.videoId) return;

    try {
      await videoGenerationApi.cancelVideo(state.videoId);
      setState(prev => ({
        ...prev,
        isGenerating: false,
        status: 'failed',
        error: 'Generation cancelled by user'
      }));
    } catch (error) {
      console.error('Failed to cancel video:', error);
    }
  }, [state.videoId]);

  const downloadVideo = useCallback(async () => {
    if (!state.videoId) return;

    try {
      const blob = await videoGenerationApi.downloadVideo(state.videoId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ai-video-${state.videoId}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      console.log('✅ Video download completed');
    } catch (error) {
      console.error('Failed to download video:', error);
    }
  }, [state.videoId]);

  return {
    ...state,
    generateVideo,
    resetGeneration,
    cancelGeneration,
    downloadVideo
  };
};