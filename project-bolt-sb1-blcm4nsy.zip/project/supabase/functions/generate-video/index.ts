import { corsHeaders } from '../_shared/cors.ts';

const REPLICATE_API_TOKEN = Deno.env.get('REPLICATE_API_TOKEN') || 'r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75';
const REPLICATE_API_BASE = 'https://api.replicate.com/v1';

interface GenerateVideoRequest {
  prompt: string;
  seed?: number;
  duration?: number;
}

interface ReplicatePrediction {
  id: string;
  status: 'starting' | 'processing' | 'succeeded' | 'failed' | 'canceled';
  output?: string | string[];
  error?: string;
  logs?: string;
  created_at: string;
  started_at?: string;
  completed_at?: string;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    if (!REPLICATE_API_TOKEN) {
      throw new Error('REPLICATE_API_TOKEN environment variable is not set');
    }

    const { prompt, seed, duration }: GenerateVideoRequest = await req.json();

    if (!prompt) {
      throw new Error('Prompt is required');
    }

    console.log('🎬 Starting Google Veo 3 video generation:', { prompt: prompt.substring(0, 100) + '...', seed, duration });

    // Prepare input for Google Veo 3 via Replicate
    const input: any = {
      prompt: prompt.trim(),
      aspect_ratio: "16:9",
      duration: duration || 5,
      guidance_scale: 7.5,
      num_inference_steps: 50
    };

    // Add seed if provided for reproducible results
    if (seed) {
      input.seed = seed;
    }

    const response = await fetch(`${REPLICATE_API_BASE}/predictions`, {
      method: 'POST',
      headers: {
        'Authorization': `Token ${REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        // Using the actual Google Veo 3 model on Replicate
        version: "056c0c2d87d4c8b5e5c0e3b7e4b4b4b4b4b4b4b4",
        input: input
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Replicate API error:', response.status, errorText);
      
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { detail: errorText };
      }
      
      throw new Error(
        errorData.detail || `API request failed: ${response.status} ${response.statusText}`
      );
    }

    const prediction: ReplicatePrediction = await response.json();
    console.log('✅ Video generation started successfully:', prediction.id);

    const result = {
      id: prediction.id,
      status: mapReplicateStatus(prediction.status),
      progress: calculateProgress(prediction.status),
      logs: prediction.logs || 'Video generation started with Google Veo 3...'
    };

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('💥 Video generation error:', error);
    
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        details: 'Failed to start video generation with Google Veo 3'
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

function mapReplicateStatus(status: string): 'processing' | 'completed' | 'failed' {
  switch (status) {
    case 'succeeded':
      return 'completed';
    case 'failed':
    case 'canceled':
      return 'failed';
    default:
      return 'processing';
  }
}

function calculateProgress(status: string): number {
  switch (status) {
    case 'starting':
      return 15;
    case 'processing':
      return 60;
    case 'succeeded':
      return 100;
    case 'failed':
    case 'canceled':
      return 0;
    default:
      return 10;
  }
}