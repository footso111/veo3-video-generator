import type { VercelRequest, VercelResponse } from '@vercel/node';

// Alternative video generation models if Veo 3 is not available
const FALLBACK_MODELS = [
  "stability-ai/stable-video-diffusion:3f0457e4619daac51203dedb1a4919c746e16d43efca3334a536a5f9ccf1c2d5",
  "anotherjesse/zeroscope-v2-xl:9f747673945c62801b13b84701c783929c0ee784e4748ec062204894dda1a351",
  "cjwbw/damo-text-to-video:1e205ea73084bd17a0a3b43396e49ba0d6bc2e754e9283b2df49fad2dcf95755"
];

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Handle CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN || 'r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75';
    
    if (!REPLICATE_API_TOKEN) {
      throw new Error('REPLICATE_API_TOKEN environment variable is not set');
    }

    const { prompt, seed, duration } = req.body;

    if (!prompt) {
      throw new Error('Prompt is required');
    }

    console.log('🎬 Starting fallback video generation:', { prompt: prompt.substring(0, 100) + '...', seed, duration });

    // Try each model until one works
    for (const model of FALLBACK_MODELS) {
      try {
        const input: any = {
          prompt: prompt.trim()
        };

        // Add seed if provided
        if (seed) {
          input.seed = seed;
        }

        const response = await fetch('https://api.replicate.com/v1/predictions', {
          method: 'POST',
          headers: {
            'Authorization': `Token ${REPLICATE_API_TOKEN}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            version: model,
            input: input
          }),
        });

        if (response.ok) {
          const prediction = await response.json();
          console.log('✅ Video generation started with fallback model:', prediction.id);

          const result = {
            id: prediction.id,
            status: 'processing',
            progress: 15,
            logs: `Video generation started with AI model: ${model.split('/')[0]}`
          };

          return res.status(200).json(result);
        }
      } catch (error) {
        console.log('❌ Model failed, trying next:', model);
        continue;
      }
    }

    throw new Error('All video generation models failed');

  } catch (error) {
    console.error('💥 Video generation error:', error);
    
    res.status(500).json({
      error: error instanceof Error ? error.message : 'Unknown error occurred',
      details: 'Failed to start video generation'
    });
  }
}