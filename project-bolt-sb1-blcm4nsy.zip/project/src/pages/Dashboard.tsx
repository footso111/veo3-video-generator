import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Video, 
  Clock, 
  MoreVertical, 
  Play,
  Download,
  Edit,
  Trash2,
  Search,
  Filter,
  Grid,
  List,
  TrendingUp,
  Sparkles,
  Users,
  Zap
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';

interface Project {
  id: string;
  name: string;
  status: 'processing' | 'completed' | 'failed';
  progress: number;
  duration: string;
  createdAt: string;
  thumbnail: string;
  prompt: string;
  views: number;
  model: string;
}

const Dashboard = () => {
  const { user } = useAuth();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'processing' | 'completed' | 'failed'>('all');

  // Mock project data for Google Veo 3 videos
  const [projects] = useState<Project[]>([
    {
      id: '1',
      name: 'Product Launch Video',
      status: 'completed',
      progress: 100,
      duration: '8s',
      createdAt: '2024-01-15',
      thumbnail: 'https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=300',
      prompt: 'A professional presenter in a modern studio announcing a revolutionary new product launch with dynamic camera movements and professional lighting',
      views: 2340,
      model: 'Google Veo 3'
    },
    {
      id: '2',
      name: 'Social Media Campaign',
      status: 'processing',
      progress: 75,
      duration: '6s',
      createdAt: '2024-01-14',
      thumbnail: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=300',
      prompt: 'An energetic content creator in a bright, colorful room enthusiastically talking about the latest social media trends',
      views: 0,
      model: 'Google Veo 3'
    },
    {
      id: '3',
      name: 'Tutorial Introduction',
      status: 'completed',
      progress: 100,
      duration: '10s',
      createdAt: '2024-01-13',
      thumbnail: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=300',
      prompt: 'A knowledgeable instructor in a clean, educational setting introducing a comprehensive tutorial series with clear, instructional speaking',
      views: 1850,
      model: 'Google Veo 3'
    },
    {
      id: '4',
      name: 'Brand Announcement',
      status: 'failed',
      progress: 0,
      duration: '7s',
      createdAt: '2024-01-12',
      thumbnail: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=300',
      prompt: 'A corporate spokesperson in a professional office environment announcing an exciting new partnership with confident authority',
      views: 0,
      model: 'Google Veo 3'
    }
  ]);

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.prompt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || project.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const stats = [
    {
      label: 'Total Videos',
      value: projects.length.toString(),
      change: '+12%',
      positive: true,
      icon: Video
    },
    {
      label: 'Processing',
      value: projects.filter(p => p.status === 'processing').length.toString(),
      change: '1 active',
      positive: true,
      icon: Clock
    },
    {
      label: 'Total Views',
      value: projects.reduce((sum, p) => sum + p.views, 0).toLocaleString(),
      change: '+25%',
      positive: true,
      icon: TrendingUp
    },
    {
      label: 'Veo 3 Generated',
      value: projects.filter(p => p.model === 'Google Veo 3').length.toString(),
      change: '+4 this week',
      positive: true,
      icon: Sparkles
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-emerald-600 bg-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400';
      case 'processing':
        return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400';
      case 'failed':
        return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400';
      default:
        return 'text-slate-600 bg-slate-100 dark:bg-slate-800 dark:text-slate-400';
    }
  };

  const ProjectCard = ({ project }: { project: Project }) => (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-all border border-slate-200 dark:border-slate-700 overflow-hidden group"
    >
      <div className="relative">
        <img 
          src={project.thumbnail} 
          alt={project.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button className="bg-white/90 backdrop-blur-sm p-3 rounded-full hover:bg-white transition-colors">
            <Play className="h-6 w-6 text-slate-900" />
          </button>
        </div>
        <div className="absolute top-3 right-3">
          <button className="bg-white/90 backdrop-blur-sm p-2 rounded-lg hover:bg-white transition-colors">
            <MoreVertical className="h-4 w-4 text-slate-700" />
          </button>
        </div>
        <div className="absolute bottom-3 left-3">
          <span className="bg-black/70 text-white px-2 py-1 rounded text-sm">
            {project.duration}
          </span>
        </div>
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center space-x-1 bg-black/70 text-white px-2 py-1 rounded text-sm">
            <Sparkles className="h-3 w-3" />
            <span>Veo 3</span>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-semibold text-slate-900 dark:text-white text-lg group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
            {project.name}
          </h3>
          <span className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(project.status)}`}>
            {project.status}
          </span>
        </div>

        {project.status === 'processing' && (
          <div className="mb-4">
            <div className="flex justify-between text-sm text-slate-600 dark:text-slate-400 mb-1">
              <span>Generating video</span>
              <span>{project.progress}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${project.progress}%` }}
              ></div>
            </div>
          </div>
        )}

        <div className="mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Sparkles className="h-4 w-4 text-purple-600" />
            <span className="text-sm font-medium text-slate-900 dark:text-white">{project.model}</span>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-2">
            {project.prompt}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm text-slate-600 dark:text-slate-400 mb-4">
          <div>
            <span className="block">Views</span>
            <span className="font-medium text-slate-900 dark:text-white">{project.views.toLocaleString()}</span>
          </div>
          <div>
            <span className="block">Created</span>
            <span className="font-medium text-slate-900 dark:text-white">{new Date(project.createdAt).toLocaleDateString()}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1 text-sm text-slate-500 dark:text-slate-400">
            <Clock className="h-4 w-4" />
            <span>{new Date(project.createdAt).toLocaleDateString()}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            {project.status === 'completed' && (
              <>
                <button className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors">
                  <Download className="h-4 w-4" />
                </button>
                <Link
                  to={`/project/${project.id}`}
                  className="p-2 text-slate-500 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                >
                  <Edit className="h-4 w-4" />
                </Link>
              </>
            )}
            <button className="p-2 text-slate-500 hover:text-red-600 transition-colors">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );

  const ProjectListItem = ({ project }: { project: Project }) => (
    <motion.div
      layout
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-all border border-slate-200 dark:border-slate-700 p-6"
    >
      <div className="flex items-center space-x-6">
        <div className="relative">
          <img 
            src={project.thumbnail} 
            alt={project.name}
            className="w-20 h-20 object-cover rounded-lg"
          />
          <div className="absolute -bottom-1 -right-1 bg-purple-600 text-white p-1 rounded text-xs">
            <Sparkles className="h-3 w-3" />
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-slate-900 dark:text-white text-lg truncate">
              {project.name}
            </h3>
            <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${getStatusColor(project.status)}`}>
              {project.status}
            </span>
          </div>
          
          {project.status === 'processing' && (
            <div className="mb-3">
              <div className="flex justify-between text-sm text-slate-600 dark:text-slate-400 mb-1">
                <span>Generating video</span>
                <span>{project.progress}%</span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${project.progress}%` }}
                ></div>
              </div>
            </div>
          )}

          <div className="flex items-center space-x-6 text-sm text-slate-600 dark:text-slate-400 mb-2">
            <span>Model: {project.model}</span>
            <span>Duration: {project.duration}</span>
            <span>Views: {project.views.toLocaleString()}</span>
            <span>{new Date(project.createdAt).toLocaleDateString()}</span>
          </div>
          
          <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-1">
            {project.prompt}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {project.status === 'completed' && (
            <>
              <button className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors">
                <Download className="h-4 w-4" />
              </button>
              <Link
                to={`/project/${project.id}`}
                className="p-2 text-slate-500 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              >
                <Edit className="h-4 w-4" />
              </Link>
            </>
          )}
          <button className="p-2 text-slate-500 hover:text-red-600 transition-colors">
            <Trash2 className="h-4 w-4" />
          </button>
          <button className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors">
            <MoreVertical className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <Navbar isAuthenticated />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                Welcome back, {user?.name}!
              </h1>
              <p className="text-slate-600 dark:text-slate-300">
                Create and manage your Google Veo 3 AI videos.
              </p>
            </div>
            
            <Link
              to="/project/new"
              className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition-all transform hover:scale-105 flex items-center space-x-2 mt-4 sm:mt-0"
            >
              <Plus className="h-5 w-5" />
              <span>Create Video</span>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                      {stat.label}
                    </p>
                    <p className="text-3xl font-bold text-slate-900 dark:text-white">
                      {stat.value}
                    </p>
                  </div>
                  <stat.icon className="h-8 w-8 text-purple-600" />
                </div>
                <div className="flex items-center mt-3">
                  <span className={`text-sm font-medium ${
                    stat.positive ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'
                  }`}>
                    {stat.change}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-6 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search videos or prompts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all text-slate-900 dark:text-white w-full sm:w-64"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Filter className="h-5 w-5 text-slate-400" />
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                  className="bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg px-3 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                >
                  <option value="all">All Status</option>
                  <option value="processing">Processing</option>
                  <option value="completed">Completed</option>
                  <option value="failed">Failed</option>
                </select>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400'
                    : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >
                <Grid className="h-5 w-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === 'list'
                    ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400'
                    : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >
                <List className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Projects */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-4">
            Your Veo 3 Videos ({filteredProjects.length})
          </h2>
          
          {filteredProjects.length === 0 ? (
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-12 text-center">
              <Sparkles className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                No videos found
              </h3>
              <p className="text-slate-600 dark:text-slate-300 mb-6">
                {searchQuery || filterStatus !== 'all' 
                  ? 'Try adjusting your search or filter criteria.'
                  : 'Get started by creating your first Google Veo 3 video.'
                }
              </p>
              <Link
                to="/project/new"
                className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all inline-flex items-center space-x-2"
              >
                <Plus className="h-5 w-5" />
                <span>Create Video</span>
              </Link>
            </div>
          ) : (
            <div className={
              viewMode === 'grid' 
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                : 'space-y-4'
            }>
              {filteredProjects.map((project) => (
                viewMode === 'grid' ? (
                  <ProjectCard key={project.id} project={project} />
                ) : (
                  <ProjectListItem key={project.id} project={project} />
                )
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;