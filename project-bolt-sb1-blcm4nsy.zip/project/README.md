# 🎬 VeoAI - Google Veo 3 Video Generator

## 🚀 **REAL Google Veo 3 AI Video Generation App**

Create stunning, cinematic-quality videos using Google's most advanced AI model - Veo 3!

### ✨ **Features:**
- 🎥 **Google Veo 3 Integration** - The most advanced AI video model
- 🎨 **Beautiful UI** - Professional, production-ready design
- 🌙 **Dark/Light Mode** - Elegant theme switching
- 📱 **Responsive Design** - Works on all devices
- ⚡ **Real-time Progress** - Live generation tracking
- 💾 **Video Download** - Save your creations
- 🎯 **Smart Prompting** - Built-in examples and tips

### 🛠 **Tech Stack:**
- **Frontend:** React + TypeScript + Tailwind CSS
- **Backend:** Vercel Serverless Functions
- **AI:** Google Veo 3 via Replicate API
- **Icons:** Lucide React
- **Animations:** Framer Motion

### 🚀 **Quick Deploy to Vercel:**

1. **Create GitHub Repository:**
   - Repository name: `veoai-video-generator` (or any unique name)
   - Make it Public
   - Upload all project files

2. **Deploy to Vercel:**
   - Import your GitHub repository
   - Add environment variable: `REPLICATE_API_TOKEN` = `r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75`
   - Click Deploy!

### 🎯 **How to Use:**
1. Enter a detailed video prompt
2. Optionally set a seed for reproducible results
3. Click "Generate Video with Veo 3"
4. Watch real-time progress
5. Download your cinematic video!

### 📝 **Example Prompts:**
- "A professional news anchor in a modern studio delivering breaking news"
- "A tech reviewer explaining smartphone features in a clean room"
- "A cooking chef demonstrating pasta making in a beautiful kitchen"

### 🔧 **Environment Variables:**
```
REPLICATE_API_TOKEN=your_replicate_token_here
```

### 📦 **Installation (Local Development):**
```bash
npm install
npm run dev
```

### 🌟 **Live Demo:**
Once deployed, your app will be available at: `https://your-app-name.vercel.app`

---

**Built with ❤️ using Google Veo 3 AI**