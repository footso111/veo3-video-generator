import { supabase } from '../lib/supabase';

export interface Project {
  id: string;
  name: string;
  description?: string;
  prompt: string;
  seed?: number;
  duration: number;
  status: 'draft' | 'processing' | 'completed' | 'failed';
  created_at: string;
  updated_at: string;
  videos?: Video[];
}

export interface Video {
  id: string;
  project_id: string;
  replicate_id?: string;
  video_url?: string;
  thumbnail_url?: string;
  duration?: number;
  status: 'processing' | 'completed' | 'failed';
  progress: number;
  error_message?: string;
  logs?: string;
  views: number;
  created_at: string;
  completed_at?: string;
}

class ProjectService {
  async createProject(data: {
    name: string;
    description?: string;
    prompt: string;
    seed?: number;
    duration?: number;
  }): Promise<Project> {
    const { data: project, error } = await supabase
      .from('projects')
      .insert({
        name: data.name,
        description: data.description,
        prompt: data.prompt,
        seed: data.seed,
        duration: data.duration || 5,
        user_id: (await supabase.auth.getUser()).data.user?.id
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create project: ${error.message}`);
    }

    return project;
  }

  async getProjects(): Promise<Project[]> {
    const { data: projects, error } = await supabase
      .from('projects')
      .select(`
        *,
        videos (*)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      throw new Error(`Failed to fetch projects: ${error.message}`);
    }

    return projects || [];
  }

  async getProject(id: string): Promise<Project> {
    const { data: project, error } = await supabase
      .from('projects')
      .select(`
        *,
        videos (*)
      `)
      .eq('id', id)
      .single();

    if (error) {
      throw new Error(`Failed to fetch project: ${error.message}`);
    }

    return project;
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project> {
    const { data: project, error } = await supabase
      .from('projects')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update project: ${error.message}`);
    }

    return project;
  }

  async deleteProject(id: string): Promise<void> {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to delete project: ${error.message}`);
    }
  }

  async createVideo(data: {
    project_id: string;
    replicate_id: string;
    status?: 'processing' | 'completed' | 'failed';
    progress?: number;
  }): Promise<Video> {
    const { data: video, error } = await supabase
      .from('videos')
      .insert({
        project_id: data.project_id,
        replicate_id: data.replicate_id,
        status: data.status || 'processing',
        progress: data.progress || 0,
        user_id: (await supabase.auth.getUser()).data.user?.id
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create video: ${error.message}`);
    }

    return video;
  }

  async updateVideo(id: string, updates: Partial<Video>): Promise<Video> {
    const { data: video, error } = await supabase
      .from('videos')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update video: ${error.message}`);
    }

    return video;
  }

  async getVideoByReplicateId(replicateId: string): Promise<Video | null> {
    const { data: video, error } = await supabase
      .from('videos')
      .select('*')
      .eq('replicate_id', replicateId)
      .single();

    if (error && error.code !== 'PGRST116') {
      throw new Error(`Failed to fetch video: ${error.message}`);
    }

    return video;
  }

  async trackUsage(action: 'video_generation' | 'api_call' | 'download', metadata?: any): Promise<void> {
    const { error } = await supabase
      .from('usage_tracking')
      .insert({
        action,
        metadata: metadata || {},
        user_id: (await supabase.auth.getUser()).data.user?.id
      });

    if (error) {
      console.error('Failed to track usage:', error);
    }
  }
}

export const projectService = new ProjectService();