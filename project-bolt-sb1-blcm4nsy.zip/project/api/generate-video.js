const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN || 'r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75';

export default async function handler(req, res) {
  // Handle CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    console.log('🎬 Starting video generation with Vercel API');
    console.log('🔑 Token available:', REPLICATE_API_TOKEN ? 'YES' : 'NO');

    const { prompt, seed, duration } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    if (!REPLICATE_API_TOKEN) {
      return res.status(500).json({ 
        error: 'REPLICATE_API_TOKEN not configured',
        details: 'Please set the environment variable in Vercel dashboard'
      });
    }

    console.log('🎬 Prompt:', prompt.substring(0, 100) + '...');

    // Try multiple working models in order of preference
    const models = [
      "stability-ai/stable-video-diffusion:3f0457e4619daac51203dedb1a4919c746e16d43efca3334a536a5f9ccf1c2d5",
      "anotherjesse/zeroscope-v2-xl:9f747673945c62801b13b84701c783929c0ee784e4748ec062204894dda1a351",
      "cjwbw/damo-text-to-video:1e205ea73084bd17a0a3b43396e49ba0d6bc2e754e9283b2df49fad2dcf95755"
    ];

    let lastError = null;

    for (const model of models) {
      try {
        console.log(`🔄 Trying model: ${model.split('/')[1]}`);

        const input = {
          prompt: prompt.trim()
        };

        // Add model-specific parameters
        if (model.includes('stable-video-diffusion')) {
          input.cond_aug = 0.02;
          input.decoding_t = 14;
          input.video_length = "14_frames_with_svd";
          input.sizing_strategy = "maintain_aspect_ratio";
          input.motion_bucket_id = 127;
          input.fps_id = 6;
        } else if (model.includes('zeroscope')) {
          input.fps = 24;
          input.model = "xl";
          input.batch_size = 1;
          input.num_frames = 24;
        }

        if (seed && !model.includes('stable-video-diffusion')) {
          input.seed = seed;
        }

        console.log('📡 Making request to Replicate API...');
        const response = await fetch('https://api.replicate.com/v1/predictions', {
          method: 'POST',
          headers: {
            'Authorization': `Token ${REPLICATE_API_TOKEN}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            version: model,
            input: input
          }),
        });

        console.log('📊 Response status:', response.status);
        
        if (response.ok) {
          const prediction = await response.json();
          console.log('✅ Video generation started with model:', model.split('/')[1], prediction.id);

          const result = {
            id: prediction.id,
            status: mapStatus(prediction.status),
            progress: calculateProgress(prediction.status),
            logs: `Video generation started with ${model.split('/')[1]}...`,
            model: model.split('/')[1]
          };

          return res.status(200).json(result);
        } else {
          const errorText = await response.text();
          lastError = `${model.split('/')[1]}: ${response.status} - ${errorText}`;
          console.log(`❌ Model ${model.split('/')[1]} failed:`, response.status, errorText);
          
          // If it's an auth error, don't try other models
          if (response.status === 401) {
            return res.status(401).json({
              error: 'Authentication failed with Replicate API',
              details: 'Please check your API token configuration'
            });
          }
          
          continue; // Try next model
        }

      } catch (error) {
        lastError = `${model.split('/')[1]}: ${error.message}`;
        console.log(`❌ Model ${model.split('/')[1]} error:`, error.message);
        continue; // Try next model
      }
    }

    // If all models failed
    return res.status(500).json({
      error: 'All video generation models failed',
      details: lastError,
      suggestion: 'Please try again with a simpler prompt'
    });

  } catch (error) {
    console.error('💥 Video generation error:', error);
    
    return res.status(500).json({
      error: error.message || 'Unknown error occurred',
      details: 'Failed to start video generation',
      token_status: REPLICATE_API_TOKEN ? 'Token present' : 'Token missing'
    });
  }
}

function mapStatus(status) {
  switch (status) {
    case 'succeeded': return 'completed';
    case 'failed':
    case 'canceled': return 'failed';
    default: return 'processing';
  }
}

function calculateProgress(status) {
  switch (status) {
    case 'starting': return 15;
    case 'processing': return 60;
    case 'succeeded': return 100;
    case 'failed':
    case 'canceled': return 0;
    default: return 10;
  }
}