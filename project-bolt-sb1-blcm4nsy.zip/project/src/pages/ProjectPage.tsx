import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft,
  Video,
  Settings,
  Download,
  Play,
  Edit3,
  Save,
  RefreshCw,
  Type,
  Clock,
  FileText,
  Zap,
  Wand2,
  Check,
  AlertCircle,
  CheckCircle,
  X,
  Lightbulb,
  Sparkles,
  Camera,
  Mic,
  Monitor,
  Copy
} from 'lucide-react';
import Navbar from '../components/Navbar';
import { videoGenerationApi } from '../services/videoGenerationApi';
import { useVideoGeneration } from '../hooks/useVideoGeneration';

const ProjectPage = () => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState<'prompt' | 'generate' | 'edit'>('prompt');
  const [prompt, setPrompt] = useState('');
  const [seed, setSeed] = useState<number | undefined>(undefined);
  const [showExamples, setShowExamples] = useState(false);
  const [showTips, setShowTips] = useState(false);

  const {
    isGenerating,
    progress,
    videoId,
    videoUrl,
    error,
    status,
    logs,
    generateVideo,
    resetGeneration,
    cancelGeneration,
    downloadVideo
  } = useVideoGeneration();
  
  // Mock project data
  const project = {
    id: id || 'new',
    name: id === 'new' ? 'New Veo 3 Video' : 'Veo 3 Video Project',
    status: 'completed' as const,
    duration: '5-10s'
  };

  const handleGenerateVideo = async () => {
    if (!prompt.trim()) {
      alert('Please enter a video prompt');
      return;
    }

    try {
      await generateVideo({
        prompt: prompt.trim(),
        seed: seed
      });
      
      setActiveTab('generate');
    } catch (error) {
      console.error('Failed to generate video:', error);
    }
  };

  const tabs = [
    { id: 'prompt', label: 'Video Prompt', icon: FileText },
    { id: 'generate', label: 'Generate', icon: Zap },
    { id: 'edit', label: 'Result', icon: Edit3 }
  ];

  const promptExamples = videoGenerationApi.getPromptExamples();
  const promptTips = videoGenerationApi.getPromptTips();

  const insertExample = (example: string) => {
    setPrompt(example);
    setShowExamples(false);
  };

  const generateRandomSeed = () => {
    setSeed(Math.floor(Math.random() * 1000000));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <Navbar isAuthenticated />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link
              to="/dashboard"
              className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeft className="h-5 w-5 text-slate-600 dark:text-slate-400" />
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                {project.name}
              </h1>
              <p className="text-slate-600 dark:text-slate-300">
                Create videos with Google Veo 3 - Advanced AI video generation
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/20 dark:to-blue-900/20 px-4 py-2 rounded-lg border border-purple-200 dark:border-purple-800">
            <Sparkles className="h-5 w-5 text-purple-600" />
            <span className="font-medium text-purple-700 dark:text-purple-300">Google Veo 3</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 mb-8">
          <div className="flex space-x-1 p-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'prompt' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                    Video Prompt
                  </h2>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setShowTips(!showTips)}
                      className="flex items-center space-x-2 px-3 py-2 bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-lg hover:bg-blue-200 dark:hover:bg-blue-900/30 transition-colors"
                    >
                      <Lightbulb className="h-4 w-4" />
                      <span>Tips</span>
                    </button>
                    <button
                      onClick={() => setShowExamples(!showExamples)}
                      className="flex items-center space-x-2 px-3 py-2 bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 rounded-lg hover:bg-purple-200 dark:hover:bg-purple-900/30 transition-colors"
                    >
                      <Wand2 className="h-4 w-4" />
                      <span>Examples</span>
                    </button>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                      Describe Your Video
                    </label>
                    <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      rows={8}
                      className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-slate-900 dark:text-white resize-none"
                      placeholder="Describe the video you want to create in detail. Include the setting, the person or subject, what they're doing, camera angles, lighting, and any specific actions or dialogue you want.

Example: A professional news anchor in a modern studio delivering breaking news about AI technology, with dynamic camera movements and professional lighting. The anchor is wearing a navy blue suit and speaks confidently to the camera."
                    />
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        {prompt.length} characters • Be detailed and specific for best results
                      </span>
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        Recommended: 100-500 characters
                      </span>
                    </div>
                  </div>

                  {/* Advanced Settings */}
                  <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-6">
                    <h3 className="font-semibold text-slate-900 dark:text-white mb-4">
                      Advanced Settings
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                          Seed (Optional)
                        </label>
                        <div className="flex space-x-2">
                          <input
                            type="number"
                            value={seed || ''}
                            onChange={(e) => setSeed(e.target.value ? parseInt(e.target.value) : undefined)}
                            className="flex-1 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-slate-900 dark:text-white"
                            placeholder="Random seed for reproducible results"
                          />
                          <button
                            onClick={generateRandomSeed}
                            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                          >
                            Random
                          </button>
                        </div>
                        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                          Use the same seed to generate similar videos. Leave empty for random results.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Tips Panel */}
                  {showTips && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-blue-900 dark:text-blue-300 flex items-center space-x-2">
                          <Lightbulb className="h-5 w-5" />
                          <span>Prompt Writing Tips</span>
                        </h3>
                        <button
                          onClick={() => setShowTips(false)}
                          className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                      <ul className="text-blue-800 dark:text-blue-400 space-y-2">
                        {promptTips.map((tip, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <span className="text-blue-600 dark:text-blue-400 mt-1">•</span>
                            <span className="text-sm">{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  )}

                  {/* Examples Panel */}
                  {showExamples && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-6"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-purple-900 dark:text-purple-300 flex items-center space-x-2">
                          <Wand2 className="h-5 w-5" />
                          <span>Example Prompts</span>
                        </h3>
                        <button
                          onClick={() => setShowExamples(false)}
                          className="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="space-y-3">
                        {promptExamples.map((example, index) => (
                          <div
                            key={index}
                            className="bg-white dark:bg-slate-800 p-4 rounded-lg border border-purple-200 dark:border-purple-700 hover:border-purple-300 dark:hover:border-purple-600 transition-colors cursor-pointer group"
                            onClick={() => insertExample(example)}
                          >
                            <div className="flex items-start justify-between">
                              <p className="text-sm text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">
                                {example}
                              </p>
                              <Copy className="h-4 w-4 text-purple-600 dark:text-purple-400 opacity-0 group-hover:opacity-100 transition-opacity ml-2 flex-shrink-0" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  <button
                    onClick={() => setActiveTab('generate')}
                    disabled={!prompt.trim()}
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-4 px-6 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  >
                    <span>Continue to Generation</span>
                    <ArrowLeft className="h-5 w-5 rotate-180" />
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'generate' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-8"
              >
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">
                  Generate with Google Veo 3
                </h2>
                
                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                      <span className="text-red-700 dark:text-red-300 font-medium">Generation Failed</span>
                    </div>
                    <p className="text-red-600 dark:text-red-400 mt-2">{error}</p>
                    <div className="flex space-x-3 mt-3">
                      <button
                        onClick={resetGeneration}
                        className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 font-medium"
                      >
                        Try Again
                      </button>
                      <button
                        onClick={() => setActiveTab('prompt')}
                        className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 font-medium"
                      >
                        Edit Prompt
                      </button>
                    </div>
                  </div>
                )}
                
                {!isGenerating && !error ? (
                  <div>
                    <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-6 mb-8">
                      <h3 className="font-semibold text-slate-900 dark:text-white mb-4">
                        Your Video Prompt
                      </h3>
                      <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-600">
                        <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                          {prompt}
                        </p>
                      </div>
                      {seed && (
                        <div className="mt-4 text-sm text-slate-600 dark:text-slate-400">
                          <span className="font-medium">Seed:</span> {seed}
                        </div>
                      )}
                    </div>

                    <div className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg p-6 mb-8 border border-purple-200 dark:border-purple-800">
                      <h3 className="font-semibold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
                        <Sparkles className="h-5 w-5 text-purple-600" />
                        <span>Google Veo 3 Features</span>
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <Camera className="h-4 w-4 text-purple-600" />
                          <span className="text-slate-700 dark:text-slate-300">Cinematic Quality</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Mic className="h-4 w-4 text-purple-600" />
                          <span className="text-slate-700 dark:text-slate-300">Natural Audio</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Monitor className="h-4 w-4 text-purple-600" />
                          <span className="text-slate-700 dark:text-slate-300">HD Resolution</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleGenerateVideo}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-4 px-6 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2"
                    >
                      <Zap className="h-5 w-5" />
                      <span>Generate Video with Veo 3</span>
                    </button>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <RefreshCw className="h-8 w-8 text-white animate-spin" />
                    </div>
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                      Google Veo 3 is Creating Your Video...
                    </h3>
                    <p className="text-slate-600 dark:text-slate-300 mb-6">
                      This may take 5-15 minutes. Veo 3 creates high-quality videos with natural audio.
                    </p>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-3 mb-4">
                      <div 
                        className="bg-gradient-to-r from-purple-600 to-blue-600 h-3 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                      {progress}% complete • Video ID: {videoId}
                    </p>
                    
                    {logs && (
                      <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4 mb-4 text-left">
                        <h4 className="font-medium text-slate-900 dark:text-white mb-2">Generation Logs:</h4>
                        <pre className="text-xs text-slate-600 dark:text-slate-400 whitespace-pre-wrap overflow-x-auto">
                          {logs}
                        </pre>
                      </div>
                    )}

                    <div className="flex justify-center space-x-4">
                      <button
                        onClick={cancelGeneration}
                        className="bg-red-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors"
                      >
                        Cancel Generation
                      </button>
                    </div>

                    {status === 'completed' && videoUrl && (
                      <div className="mt-6">
                        <div className="flex items-center justify-center space-x-2 text-emerald-600 dark:text-emerald-400 mb-4">
                          <CheckCircle className="h-5 w-5" />
                          <span className="font-medium">Video generation completed!</span>
                        </div>
                        <button
                          onClick={() => setActiveTab('edit')}
                          className="bg-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors"
                        >
                          View Generated Video
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'edit' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                    Generated Video
                  </h2>
                  <button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:shadow-lg transition-all flex items-center space-x-2">
                    <Save className="h-4 w-4" />
                    <span>Save Project</span>
                  </button>
                </div>

                <div className="aspect-video bg-slate-100 dark:bg-slate-700 rounded-lg mb-6 flex items-center justify-center">
                  {videoUrl ? (
                    <video 
                      src={videoUrl} 
                      controls 
                      className="w-full h-full rounded-lg"
                    >
                      Your browser does not support the video tag.
                    </video>
                  ) : (
                    <div className="text-center">
                      <Video className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                      <p className="text-slate-600 dark:text-slate-400">
                        {status === 'completed' ? 'Video ready for viewing' : 'Your generated video will appear here'}
                      </p>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-6">
                    <h3 className="font-semibold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
                      <Download className="h-5 w-5" />
                      <span>Download & Share</span>
                    </h3>
                    <div className="space-y-3">
                      <button 
                        onClick={downloadVideo}
                        disabled={!videoUrl}
                        className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Download MP4
                      </button>
                      <button 
                        disabled={!videoUrl}
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Share Video
                      </button>
                      <button 
                        disabled={!videoUrl}
                        className="w-full bg-emerald-600 text-white py-2 px-4 rounded-lg hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Copy Link
                      </button>
                    </div>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-6">
                    <h3 className="font-semibold text-slate-900 dark:text-white mb-4">
                      Video Details
                    </h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600 dark:text-slate-300">Status:</span>
                        <span className={`font-medium capitalize ${
                          status === 'completed' ? 'text-emerald-600 dark:text-emerald-400' :
                          status === 'processing' ? 'text-blue-600 dark:text-blue-400' :
                          status === 'failed' ? 'text-red-600 dark:text-red-400' :
                          'text-slate-600 dark:text-slate-400'
                        }`}>
                          {status}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600 dark:text-slate-300">Model:</span>
                        <span className="font-medium text-slate-900 dark:text-white">Google Veo 3</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600 dark:text-slate-300">Quality:</span>
                        <span className="font-medium text-slate-900 dark:text-white">HD</span>
                      </div>
                      {seed && (
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-300">Seed:</span>
                          <span className="font-medium text-slate-900 dark:text-white font-mono text-xs">
                            {seed}
                          </span>
                        </div>
                      )}
                      {videoId && (
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-300">Video ID:</span>
                          <span className="font-medium text-slate-900 dark:text-white font-mono text-xs">
                            {videoId}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {prompt && (
                  <div className="mt-6 bg-slate-50 dark:bg-slate-700 rounded-lg p-6">
                    <h3 className="font-semibold text-slate-900 dark:text-white mb-3">
                      Original Prompt
                    </h3>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      {prompt}
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Video Preview */}
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-6">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-4">
                Preview
              </h3>
              <div className="aspect-video bg-slate-100 dark:bg-slate-700 rounded-lg flex items-center justify-center mb-4">
                {videoUrl ? (
                  <video 
                    src={videoUrl} 
                    className="w-full h-full rounded-lg object-cover"
                  />
                ) : (
                  <div className="text-center">
                    <Sparkles className="h-12 w-12 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Veo 3 video preview
                    </p>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-center space-x-4">
                <button className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                  <Play className="h-5 w-5 text-slate-600 dark:text-slate-400" />
                </button>
                <div className="flex-1 bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                  <div className="bg-purple-600 h-2 rounded-full w-1/3"></div>
                </div>
                <span className="text-sm text-slate-600 dark:text-slate-400">
                  5-10s
                </span>
              </div>
            </div>

            {/* Project Settings */}
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-6">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Project Settings</span>
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Project Name
                  </label>
                  <input
                    type="text"
                    value={project.name}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Description
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Add a description for this Veo 3 video..."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-slate-900 dark:text-white resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Progress Stats */}
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-6">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-4">
                Progress
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600 dark:text-slate-300">Prompt</span>
                  <span className={`text-sm font-medium ${prompt.trim() ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`}>
                    {prompt.trim() ? 'Complete' : 'Pending'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600 dark:text-slate-300">Generate</span>
                  <span className={`text-sm font-medium capitalize ${
                    status === 'completed' ? 'text-emerald-600 dark:text-emerald-400' :
                    status === 'processing' ? 'text-blue-600 dark:text-blue-400' :
                    status === 'failed' ? 'text-red-600 dark:text-red-400' :
                    'text-slate-400'
                  }`}>
                    {status === 'idle' ? 'Pending' : status}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600 dark:text-slate-300">Download</span>
                  <span className={`text-sm font-medium ${videoUrl ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`}>
                    {videoUrl ? 'Ready' : 'Pending'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectPage;