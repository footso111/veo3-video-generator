import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Check, 
  Crown, 
  Zap, 
  Users, 
  CreditCard,
  Calendar,
  TrendingUp,
  Download,
  Clock,
  Shield
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';

const SubscriptionPage = () => {
  const { user, updateUser } = useAuth();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const plans = [
    {
      id: 'free',
      name: 'Free',
      description: 'Perfect for getting started',
      price: { monthly: 0, yearly: 0 },
      features: [
        '5 minutes of captions per month',
        'Basic accuracy AI',
        'Standard support',
        'Export to SRT',
        'Basic editing tools'
      ],
      limitations: [
        'Limited to 5 minutes/month',
        'Basic accuracy only',
        'No priority support'
      ],
      popular: false,
      current: user?.plan === 'free'
    },
    {
      id: 'pro',
      name: 'Pro',
      description: 'For content creators and professionals',
      price: { monthly: 29, yearly: 290 },
      features: [
        '500 minutes of captions per month',
        'High accuracy AI',
        'Priority support',
        'All export formats (SRT, VTT, TXT)',
        'Advanced editing tools',
        'Custom vocabulary',
        'Batch processing',
        'Speaker identification',
        'Multiple languages'
      ],
      limitations: [],
      popular: true,
      current: user?.plan === 'pro'
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      description: 'For large organizations and teams',
      price: { monthly: 99, yearly: 990 },
      features: [
        'Unlimited captions',
        'Maximum accuracy AI',
        'Dedicated support manager',
        'API access',
        'Custom integrations',
        'SLA guarantee',
        'Team collaboration',
        'Advanced analytics',
        'White-label options',
        'Custom branding',
        'SSO integration'
      ],
      limitations: [],
      popular: false,
      current: user?.plan === 'enterprise'
    }
  ];

  const usageStats = [
    {
      label: 'Minutes Used',
      value: '156',
      limit: user?.plan === 'free' ? '5' : user?.plan === 'pro' ? '500' : '∞',
      percentage: user?.plan === 'free' ? 100 : 31
    },
    {
      label: 'Projects Created',
      value: '12',
      limit: '∞',
      percentage: 0
    },
    {
      label: 'API Calls',
      value: '2,340',
      limit: user?.plan === 'enterprise' ? '∞' : '0',
      percentage: user?.plan === 'enterprise' ? 23 : 0
    }
  ];

  const handleUpgrade = (planId: string) => {
    updateUser({ plan: planId as any });
    // In a real app, this would integrate with a payment processor
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <Navbar isAuthenticated />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-4">
            Subscription & Billing
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Manage your subscription and track your usage
          </p>
        </div>

        {/* Current Plan */}
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                Current Plan
              </h2>
              <div className="flex items-center space-x-3">
                <span className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent capitalize">
                  {user?.plan}
                </span>
                {user?.plan === 'pro' && <Crown className="h-6 w-6 text-yellow-500" />}
                {user?.plan === 'enterprise' && <Shield className="h-6 w-6 text-purple-600" />}
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-600 dark:text-slate-400">Next billing date</div>
              <div className="font-semibold text-slate-900 dark:text-white">
                {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Usage Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {usageStats.map((stat, index) => (
              <div key={index} className="bg-slate-50 dark:bg-slate-700 rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
                    {stat.label}
                  </span>
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    {stat.value} / {stat.limit}
                  </span>
                </div>
                <div className="text-2xl font-bold text-slate-900 dark:text-white mb-3">
                  {stat.value}
                </div>
                {stat.percentage > 0 && (
                  <div className="w-full bg-slate-200 dark:bg-slate-600 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all ${
                        stat.percentage > 80 ? 'bg-red-500' : 
                        stat.percentage > 60 ? 'bg-yellow-500' : 
                        'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(stat.percentage, 100)}%` }}
                    ></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Billing Toggle */}
        <div className="flex justify-center mb-8">
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-2 flex">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-6 py-2 rounded-lg font-medium transition-all relative ${
                billingCycle === 'yearly'
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Yearly
              <span className="absolute -top-2 -right-2 bg-emerald-500 text-white text-xs px-2 py-1 rounded-full">
                Save 17%
              </span>
            </button>
          </div>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`relative bg-white dark:bg-slate-800 rounded-xl shadow-lg border-2 transition-all hover:shadow-xl ${
                plan.popular 
                  ? 'border-purple-500 ring-2 ring-purple-500 ring-opacity-20' 
                  : plan.current
                  ? 'border-emerald-500 ring-2 ring-emerald-500 ring-opacity-20'
                  : 'border-slate-200 dark:border-slate-700'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                </div>
              )}

              {plan.current && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-emerald-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Current Plan
                  </div>
                </div>
              )}
              
              <div className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-300 mb-4">
                    {plan.description}
                  </p>
                  <div className="flex items-baseline justify-center mb-2">
                    <span className="text-4xl font-bold text-slate-900 dark:text-white">
                      ${plan.price[billingCycle]}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 ml-1">
                      /{billingCycle === 'monthly' ? 'month' : 'year'}
                    </span>
                  </div>
                  {billingCycle === 'yearly' && plan.price.yearly > 0 && (
                    <div className="text-sm text-emerald-600 dark:text-emerald-400">
                      Save ${(plan.price.monthly * 12) - plan.price.yearly} per year
                    </div>
                  )}
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start space-x-3">
                      <Check className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <span className="text-slate-600 dark:text-slate-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleUpgrade(plan.id)}
                  disabled={plan.current}
                  className={`w-full py-3 px-6 rounded-lg font-semibold transition-all ${
                    plan.current
                      ? 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed'
                      : plan.popular
                      ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:shadow-lg transform hover:scale-105'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-600'
                  }`}
                >
                  {plan.current ? 'Current Plan' : plan.id === 'free' ? 'Downgrade' : 'Upgrade'}
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Billing History */}
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              Billing History
            </h2>
            <button className="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 font-medium">
              Download All
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left py-3 px-4 font-medium text-slate-600 dark:text-slate-400">Date</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-600 dark:text-slate-400">Description</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-600 dark:text-slate-400">Amount</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-600 dark:text-slate-400">Status</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-600 dark:text-slate-400">Invoice</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100 dark:border-slate-700">
                  <td className="py-4 px-4 text-slate-900 dark:text-white">Jan 15, 2024</td>
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-300">Pro Plan - Monthly</td>
                  <td className="py-4 px-4 text-slate-900 dark:text-white font-medium">$29.00</td>
                  <td className="py-4 px-4">
                    <span className="bg-emerald-100 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 px-2 py-1 rounded-full text-sm">
                      Paid
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <button className="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300">
                      <Download className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
                <tr className="border-b border-slate-100 dark:border-slate-700">
                  <td className="py-4 px-4 text-slate-900 dark:text-white">Dec 15, 2023</td>
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-300">Pro Plan - Monthly</td>
                  <td className="py-4 px-4 text-slate-900 dark:text-white font-medium">$29.00</td>
                  <td className="py-4 px-4">
                    <span className="bg-emerald-100 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 px-2 py-1 rounded-full text-sm">
                      Paid
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <button className="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300">
                      <Download className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPage;