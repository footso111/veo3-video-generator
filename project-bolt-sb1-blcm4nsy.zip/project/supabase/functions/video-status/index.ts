import { corsHeaders } from '../_shared/cors.ts';

const REPLICATE_API_TOKEN = Deno.env.get('REPLICATE_API_TOKEN') || 'r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75';
const REPLICATE_API_BASE = 'https://api.replicate.com/v1';

interface ReplicatePrediction {
  id: string;
  status: 'starting' | 'processing' | 'succeeded' | 'failed' | 'canceled';
  output?: string | string[];
  error?: string;
  logs?: string;
  created_at: string;
  started_at?: string;
  completed_at?: string;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    if (!REPLICATE_API_TOKEN) {
      throw new Error('REPLICATE_API_TOKEN environment variable is not set');
    }

    const url = new URL(req.url);
    const videoId = url.searchParams.get('id');

    if (!videoId) {
      throw new Error('Video ID is required');
    }

    console.log('🔍 Checking Google Veo 3 video status:', videoId);

    const response = await fetch(`${REPLICATE_API_BASE}/predictions/${videoId}`, {
      headers: {
        'Authorization': `Token ${REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Replicate API error:', response.status, errorText);
      
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { detail: errorText };
      }
      
      throw new Error(
        errorData.detail || `API request failed: ${response.status} ${response.statusText}`
      );
    }

    const prediction: ReplicatePrediction = await response.json();
    console.log('📊 Video status update:', prediction.status, prediction.id);

    // Handle output - Google Veo 3 can return string or array
    let videoUrl: string | undefined;
    if (prediction.output) {
      if (Array.isArray(prediction.output)) {
        videoUrl = prediction.output[0];
      } else {
        videoUrl = prediction.output;
      }
    }

    const result = {
      id: prediction.id,
      status: mapReplicateStatus(prediction.status),
      progress: calculateProgress(prediction.status, prediction.logs),
      video_url: videoUrl,
      duration: videoUrl ? estimateDuration(prediction.logs || '') : undefined,
      error: prediction.error || undefined,
      logs: prediction.logs || 'Processing with Google Veo 3...'
    };

    if (result.status === 'completed' && videoUrl) {
      console.log('🎉 Video generation completed successfully!', videoUrl);
    }

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('💥 Video status error:', error);
    
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        details: 'Failed to get video status from Google Veo 3'
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

function mapReplicateStatus(status: string): 'processing' | 'completed' | 'failed' {
  switch (status) {
    case 'succeeded':
      return 'completed';
    case 'failed':
    case 'canceled':
      return 'failed';
    default:
      return 'processing';
  }
}

function calculateProgress(status: string, logs?: string): number {
  // Try to extract progress from logs if available
  if (logs) {
    const progressMatch = logs.match(/(\d+)%/);
    if (progressMatch) {
      return parseInt(progressMatch[1]);
    }
  }

  switch (status) {
    case 'starting':
      return 15;
    case 'processing':
      return 60;
    case 'succeeded':
      return 100;
    case 'failed':
    case 'canceled':
      return 0;
    default:
      return 10;
  }
}

function estimateDuration(logs: string): number {
  // Try to extract duration from logs or default to 5 seconds
  const durationMatch = logs.match(/duration[:\s]+(\d+)/i);
  return durationMatch ? parseInt(durationMatch[1]) : 5;
}