// REAL API Integration - Uses Vercel API routes properly
const REPLICATE_API_TOKEN = import.meta.env.VITE_REPLICATE_API_TOKEN || 'r8_alsIUdwjgBEDxOggigci73uQj19BhSj28KF75';

export interface GenerateVideoRequest {
  prompt: string;
  seed?: number;
  duration?: number;
}

export interface GenerateVideoResponse {
  id: string;
  status: 'processing' | 'completed' | 'failed';
  progress?: number;
  video_url?: string;
  thumbnail_url?: string;
  duration?: number;
  error?: string;
  logs?: string;
  model?: string;
}

class VideoGenerationService {
  private getApiUrl(): string {
    // Check if we're in production (Vercel) or development
    if (typeof window !== 'undefined') {
      const hostname = window.location.hostname;
      if (hostname.includes('vercel.app') || hostname.includes('your-domain.com')) {
        // Production Vercel URL
        return window.location.origin;
      }
    }
    // Development or fallback
    return window.location.origin;
  }

  async generateVideo(request: GenerateVideoRequest): Promise<GenerateVideoResponse> {
    console.log('🎬 Starting video generation...');
    
    try {
      const apiUrl = this.getApiUrl();
      console.log('📡 Using API URL:', apiUrl);
      
      const response = await fetch(`${apiUrl}/api/generate-video`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: request.prompt.trim(),
          seed: request.seed,
          duration: request.duration || 5
        }),
      });

      console.log('📊 Response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ 
          error: `Network error: ${response.status} ${response.statusText}` 
        }));
        
        console.error('❌ API Error:', errorData);
        
        // Provide helpful error messages
        if (response.status === 500) {
          throw new Error(
            errorData.error || 
            'Video generation service is temporarily unavailable. Please try again in a few minutes.'
          );
        } else if (response.status === 404) {
          throw new Error('Video generation API not found. Please check your deployment configuration.');
        } else if (response.status === 401) {
          throw new Error('API authentication failed. Please check your configuration.');
        } else if (response.status === 429) {
          throw new Error('Rate limit exceeded. Please wait a moment before trying again.');
        } else {
          throw new Error(errorData.error || `Request failed: ${response.status}`);
        }
      }

      const result = await response.json();
      console.log('✅ Video generation started:', result.id);
      return result;

    } catch (error) {
      console.error('💥 Video generation failed:', error);
      
      // Provide user-friendly error messages
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error('Network connection failed. Please check your internet connection and try again.');
      }
      
      throw new Error(error instanceof Error ? error.message : 'Video generation failed. Please try again.');
    }
  }

  async getVideoStatus(videoId: string): Promise<GenerateVideoResponse> {
    console.log('🔍 Checking video status:', videoId);
    
    try {
      const apiUrl = this.getApiUrl();
      
      const response = await fetch(`${apiUrl}/api/video-status?id=${videoId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ 
          error: `Status check failed: ${response.status}` 
        }));
        throw new Error(errorData.error || `Status check failed: ${response.status}`);
      }

      const result = await response.json();
      return result;

    } catch (error) {
      console.error('💥 Status check failed:', error);
      throw new Error(error instanceof Error ? error.message : 'Status check failed');
    }
  }

  async cancelVideo(videoId: string): Promise<void> {
    console.log('🛑 Cancelling video:', videoId);
    // Implementation for cancelling video
  }

  async downloadVideo(videoId: string): Promise<Blob> {
    console.log('⬇️ Downloading video:', videoId);
    
    const status = await this.getVideoStatus(videoId);
    
    if (!status.video_url) {
      throw new Error('Video not ready for download');
    }

    try {
      const response = await fetch(status.video_url);
      
      if (!response.ok) {
        throw new Error(`Download failed: ${response.status}`);
      }
      
      return response.blob();
    } catch (error) {
      console.error('Failed to download video:', error);
      throw new Error(`Download failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Helper methods
  getPromptExamples(): string[] {
    return [
      "A professional news anchor in a modern studio delivering breaking news",
      "A tech reviewer explaining smartphone features in a clean room",
      "A cooking chef demonstrating pasta making in a beautiful kitchen",
      "A fitness instructor leading a workout session in a bright gym",
      "A travel vlogger exploring a mountain landscape",
      "A business presenter giving a product pitch in a modern office"
    ];
  }

  getPromptTips(): string[] {
    return [
      "Keep prompts simple and clear for best results",
      "Describe the main subject and setting",
      "Mention the type of action or movement you want",
      "Avoid overly complex or abstract concepts",
      "Use descriptive but concise language",
      "Focus on visual elements rather than dialogue"
    ];
  }
}

export const videoGenerationApi = new VideoGenerationService();